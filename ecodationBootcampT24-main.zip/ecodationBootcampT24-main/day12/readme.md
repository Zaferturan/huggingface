https://www.kaggle.com/code/drmurataltun/titanic-veri-gorselle-tirme
