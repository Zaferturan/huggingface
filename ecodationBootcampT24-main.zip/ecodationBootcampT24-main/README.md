# ecodationBootcampT24
Ecodation Bootcamp Temmuz 2024
Merhaba Arkdaşlar bu respository Ecodation Eğitim tarafndan düzenlenen YZ ve ML Bootcamp dosyalarını içermektedir.
